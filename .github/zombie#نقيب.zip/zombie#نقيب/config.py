import os
from os import getenv
from dotenv import load_dotenv
from OWNER import BOT_TOKEN, OWNER, OWNER_NAME, DATABASE, CHANNEL, GROUP, LOGS, VIDEO

if os.path.exists("local.env"):
    load_dotenv("local.env")

load_dotenv()
admins = {6287764186}
user = {'@A_R_53'}
call = {}
dev = {'@A_R_53}
logger = {}
logger_mode = {}
botname = {'دراك'}
appp = {}
helper = {}



API_ID = int(getenv("API_ID", "8186557"))
API_HASH = getenv("API_HASH", "efd77b34c69c164ce158037ff5a0d117")
BOT_TOKEN =  '5948933883:AAG15erj0ptKKewPdr-QMwZfZDDU2a-0NOY'
MONGO_DB_URL = DATABASE
OWNER = OWNER
OWNER_NAME ='KING DARK'
CHANNEL = CHANNEL
GROUP = 1807463090
LOGS = LOGS
VIDEO = VIDEO
