# متطلبات التنصيب #
OWNER = ["A_R_53"]
OWNER_NAME = "KING DARK"
BOT_TOKEN = "5948933883:AAG15erj0ptKKewPdr-QMwZfZDDU2a-0NOY"
DATABASE = "mongodb+srv://Elkber:Elkber@cluster0.feuljpn.mongodb.net/?retryWrites=true&w=majority"
CHANNEL = "https://t.me/zombieyy"
GROUP = "https://t.me/zombie2"
VIDEO = "https://telegra.ph/file/770e2d5df0b50264097b2.jpg"
LOGS = "zombie2"

